from operation import mymath


def lambda_handler(event,context):                                              #event is a dictionary
    if event['request']['type'] == "LaunchRequest":
        return on_launch(event,context)
    elif event['request']['type'] == "IntentRequest":
        return intent_router(event,context)




#LAUNCH EVENT
def on_launch(event,context):
    intro = """Welcome to dj math! Tell me two numbers and operation, and I will tell you the result """
    return statement("Greetings", intro)

def statement(title,body):
    speechlet = {}
    speechlet['outputSpeech'] = build_PlainSpeech(body)
    speechlet['card'] = build_SimpleCard(title,body)
    speechlet['shouldEndSession'] = False
    return build_response(speechlet)

def endstatement(title,body):
    speechlet = {}
    speechlet['outputSpeech'] = build_PlainSpeech(body)
    speechlet['card'] = build_SimpleCard(title,body)
    speechlet['shouldEndSession'] = True
    return build_response(speechlet)

def build_PlainSpeech(body):
    speech = {}
    speech['type'] = 'PlainText'
    speech['text'] = body
    return speech

def build_SimpleCard(title,body):
    card = {}
    card['type'] = 'Simple'
    card['title'] = title
    card['content'] = body
    return card

def build_response(message,session_attributes={}):
    response = {}
    response['version'] = '1.0'
    response['sessionAttributes'] = session_attributes
    response['response'] = message
    return response



#INTENT REQUEST

def intent_router(event,context):
    intent = event['request']['intent']['name']
    if intent == "MathIntent":
        return math_number_intent(event, context)


        #BUILT IN INTENTS:

    if intent == "AMAZON.CancelIntent":
        return cancel_intent()
    if intent == "AMAZON.HelpIntent":
        return help_intent()
    if intent == "AMAZON.StopIntent":
        return stop_intent()



def math_number_intent(event, context):
    slots = event['request']['intent']['slots']
    num1  = slots['numberone']['value']
    num2  = slots['numbertwo']['value']
    oper  = slots['operations']['value']
    a     = mymath(num1,num2,oper)
    answer = str(a)
    return statement("final answer",answer)





def cancel_intent():
    return statement("CancelIntent","You want to  cancel?")

def help_intent():
    return statement("HelpIntent","You want Help?")

def stop_intent():
    return endstatement("StopIntent","Good Bye")
