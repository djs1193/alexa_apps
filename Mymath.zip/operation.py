def mymath(n1,n2,op):
    n1 = int(n1)
    n2 = int(n2)
    if op == "add":
        res = n1 + n2
    if op == "subtract":
        res = n2 - n1
    if op == "multiply":
        res = n1 * n2
    if op == "divide":
        res = float(n1/n2)
    return (res)
