
from lucky_number_list import *


def lambda_handler(event,context):                                              #event is a dictionary
    if event['request']['type'] == "LaunchRequest":
        return on_launch(event,context)
    elif event['request']['type'] == "IntentRequest":
        return intent_router(event,context)



def on_launch(event,context):
    intro = """ Hi I am genie. You can ask me my favorite number,
                or you can ask me if a number is lucky."""
    return statement("Greetings",intro)

def statement(title,body):                                                       #we create a speechlet dictionary
    speechlet = {}
    speechlet['outputSpeech'] = build_PlainSpeech(body)                          #This is what alexa will actually say out
    speechlet['card'] = build_SimpleCard(title,body)                             #Used for documentation say on phone
    speechlet['shouldEndSession'] = False                                         #do you want to end the session or not
    return build_response(speechlet)

def endstatement(title,body):
    speechlet = {}
    speechlet['outputSpeech'] = build_PlainSpeech(body)
    speechlet['card'] = build_SimpleCard(title,body)
    speechlet['shouldEndSession'] = True
    return build_response(speechlet)

def build_PlainSpeech(body):
    speech = {}
    speech['type'] = 'PlainText'
    speech['text'] = body
    return speech

def build_SimpleCard(title,body):
    card = {}
    card['type'] = 'Simple'
    card['title'] = title
    card['content'] = body
    return card

def build_response(message,session_attributes={}):                               #This is what will be set up in Lambda response
    response = {}
    response['version'] = '1.0'
    response['sessionAttributes'] = session_attributes
    response['response'] = message
    return response





def intent_router(event,context):
    intent = event['request']['intent']['name']

    if intent == "FavoriteNumberIntent":
        return favorite_number_intent(event, context)

    if intent == "LuckyNumberIntent":
        return lucky_number_intent(event, context)

    if intent == "AMAZON.CancelIntent":
            return cancel_intent()
    if intent == "AMAZON.HelpIntent":
            return help_intent()
    if intent == "AMAZON.StopIntent":
            return stop_intent()


def favorite_number_intent(event,context):
    return statement("Favorite number","My favorite number is 11!")

def lucky_number_intent(event, context):
    slots = event['request']['intent']['slots']

    if (slots['number']['value']) in mylist:                                        #myunmber is the slot given by us
        return statement("Lucky","Yes")
    else:
        return statement("Lucky","No")


def help_intent():
    intro = """ Hi I am genie. You can ask me my favorite number,
                or you can ask me if a number is lucky."""
    return statement("HelpIntent",intro)

def stop_intent():
    return endstatement("StopIntent","Good Bye")
